<?php
/**
 * Plugin Name: CodeBreakerRU Currency to LKR
 * Plugin URI: https://github.com/CodeBreakerRU
 * Author: CodeBreakerRU
 * Author URI: https://github.com/CodeBreakerRU
 * Description: Currency to LKR
 * Version: 1.0.1
 * License: GPL2 or Later.
 * License URL: https://apache.org/licenses/LICENSE-2.0
 * text-domain: prefix-plugin-name
*/

add_filter( 'woocommerce_currency_symbol', 'lk_currency_symbol', 10, 2 );
function lk_currency_symbol( $currency_symbol, $currency ) {
  if ( $currency == 'LKR' ) {
    $currency_symbol = 'LKR ';
  }
  return $currency_symbol;
}

?>